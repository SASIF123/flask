import time
ts = str(int(time.time()))
b = './static/image/'+ts+".svg"
print(b)         
