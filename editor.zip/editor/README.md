# StarMapGenerator-v2

1. please install all libraries including skyfield.
2. python StarsXY.py
then result svg file will save in the next location
/Users/hazze/Documents/Python Scripts/StarMap/CreatedMaps